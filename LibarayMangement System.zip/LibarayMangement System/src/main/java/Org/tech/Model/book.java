package Org.tech.Model;

public class book {
private int bookid;
private String Title;
private String Author;
private String Publisher;
private String Publication_Date;
private String ISBN;
public int getBookid() {
	return bookid;
}
public void setBookid(int bookid) {
	this.bookid = bookid;
}
public String getTitle() {
	return Title;
}
public void setTitle(String title) {
	Title = title;
}
public String getAuthor() {
	return Author;
}
public void setAuthor(String author) {
	Author = author;
}
public String getPublisher() {
	return Publisher;
}
public void setPublisher(String publisher) {
	Publisher = publisher;
}
public String getPublication_Date() {
	return Publication_Date;
}
public void setPublication_Date(String publication_Date) {
	Publication_Date = publication_Date;
}
public String getISBN() {
	return ISBN;
}
public void setISBN(String iSBN) {
	ISBN = iSBN;
}


}
