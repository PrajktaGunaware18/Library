package Org.tech.Model;

public class FineFee {
	private int fineId;
	private String borrow_date;
	public String getBorrow_date() {
		return borrow_date;
	}
	public void setBorrow_date(String borrow_date) {
		this.borrow_date = borrow_date;
	}
	private int Fine_Amount;
	private String Payment_Status;
	public int getFineId() {
		return fineId;
	}
	public void setFineId(int fineId) {
		this.fineId = fineId;
	}
	
	public int getFine_Amount() {
		return Fine_Amount;
	}
	public void setFine_Amount(int fine_Amount) {
		Fine_Amount = fine_Amount;
	}
	public String getPayment_Status() {
		return Payment_Status;
	}
	public void setPayment_Status(String payment_Status) {
		Payment_Status = payment_Status;
	}

}
