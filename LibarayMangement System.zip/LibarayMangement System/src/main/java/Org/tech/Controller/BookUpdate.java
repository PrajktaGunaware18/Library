package Org.tech.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Org.tech.Model.book;
import Org.tech.servies.bookservicesIMPL;


@WebServlet("/BookUpdate")
public class BookUpdate extends HttpServlet {
	bookservicesIMPL bservice=new bookservicesIMPL();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
        int Id=Integer.parseInt(request.getParameter("Id"));
        String Title=request.getParameter("Title");
        String Author=request.getParameter("Author");
        String Publisher=request.getParameter("Publisher");
        String Publication_Date=request.getParameter("Publication_Date");
        String ISBN=request.getParameter("ISBN");
        book b=new book();
        b.setBookid(Id);
        b.setTitle(Title);
        b.setAuthor(Author);
        b.setPublisher(Publisher);
        b.setPublication_Date(Publication_Date);
        b.setISBN(ISBN);
        boolean result=bservice.isUpdatebook(Id,Title,Author,Publisher,Publication_Date,ISBN);
        if(result)
        {
        	RequestDispatcher r1=request.getRequestDispatcher("ViewBook.jsp");
 		   r1.forward(request,response);
        }
        else
        {
        	out.println("<h1> not updated </h1>");
        }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
