package Org.tech.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Org.tech.Model.StudentUser;
import Org.tech.servies.StudentUserServiceesIMPL;
import jakarta.servlet.RequestDispatcher;


@WebServlet("/AddStudentUser")
public class AddStudentUser extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentUserServiceesIMPL services=new StudentUserServiceesIMPL();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String FullName=request.getParameter("fullname");
		 String username=request.getParameter("username");
		 String Password=request.getParameter("password");
		 String Email=request.getParameter("email");
		String Phonenumber=request.getParameter("phonenumber");
		String Address=request.getParameter("address"); 
		StudentUser std=new StudentUser();
		std.setFullName(FullName);
		std.setUsername(username);
		std.setPassword(Password);
		std.setEmail(Email);
		std.setPhonenumber(Phonenumber);
		std.setAddress(Address);
		boolean b=services.isAddStudent(std);
		if(b)
		{
			javax.servlet.RequestDispatcher r=request.getRequestDispatcher("StudentAdd.jsp");
			r.forward(request, response);
			out.println("<h1>Student Add Sccessfully</h1>");
			
		}
		else
		{
			javax.servlet.RequestDispatcher r=request.getRequestDispatcher("StudentAdd.jsp");
			r.forward(request, response);
			out.println("<h1>Student Add Sccessfully</h1>");
			
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
