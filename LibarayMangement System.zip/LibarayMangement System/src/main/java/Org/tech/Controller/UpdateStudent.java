package Org.tech.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Org.tech.servies.StudentUserServiceesIMPL;
import Org.tech.Model.*;

@WebServlet("/UpdateStudent")
public class UpdateStudent extends HttpServlet {
	StudentUserServiceesIMPL student=new StudentUserServiceesIMPL();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int id = Integer.parseInt(request.getParameter("Id"));
		String Fullname=request.getParameter("Fullname");
		String Usernmae=request.getParameter("Username");
		String Password=request.getParameter("Password");
		String Email=request.getParameter("Email");
		String Phonenumber=request.getParameter("Phonenumber");
		String Address=request.getParameter("Address");
		StudentUser s=new StudentUser();
		s.setStudentId(id);
		s.setFullName(Fullname);
		s.setUsername(Usernmae);
		s.setEmail(Email);
		s.setPhonenumber(Phonenumber);
		s.setAddress(Address);
		boolean b=student.isUpdateStudent(id, Fullname, Usernmae, Password, Email, Phonenumber, Address);
		if(b)
		{
			RequestDispatcher r1=request.getRequestDispatcher("ViewStudent.jsp");
	 		   r1.forward(request,response);
		}
		else
		{
			RequestDispatcher r1=request.getRequestDispatcher("ViewStudent.jsp");
	 		   r1.forward(request,response);
	 		   out.println("<h1>Some Problem Not update Please Check</h1>");
		}
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
