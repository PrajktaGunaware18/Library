package Org.tech.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Org.tech.Model.book;
import Org.tech.servies.bookservicesIMPL;


@WebServlet("/bookAdd")
public class bookAdd extends HttpServlet {
	bookservicesIMPL bookservices=new bookservicesIMPL();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String Title=request.getParameter("Title");
		String Author=request.getParameter("Author");
		String Publisher=request.getParameter("Publisher");
		String Publication_Date=request.getParameter("Publication_Date");
		String ISBN=request.getParameter("ISBN");
		book b=new book();
		b.setTitle(Title);
		b.setAuthor(Author);
		b.setPublisher(Publisher);
		b.setPublication_Date(Publication_Date);
		b.setISBN(ISBN);
		boolean result=bookservices.isAddBook(b);
		if(result)
		{
			javax.servlet.RequestDispatcher r=request.getRequestDispatcher("ViewBook.jsp");
			r.forward(request, response);
			out.println("<h1>Book Add Sccessfully</h1>");
		}
		else
		{
			javax.servlet.RequestDispatcher r=request.getRequestDispatcher("ViewBook.jsp");
			r.forward(request, response);
			out.println("<h1>Book not Add Sccessfully</h1>");
			
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
