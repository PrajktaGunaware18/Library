package Org.tech.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BookUpdateFinal
 */
@WebServlet("/BookUpdateFinal")
public class BookUpdateFinal extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		 int Id=Integer.parseInt(request.getParameter("Id"));
        String Title=request.getParameter("Title");
        String Author=request.getParameter("Author");
        String Publisher=request.getParameter("Publisher");
        String Publication_Date=request.getParameter("Publication_Date");
        String ISBN=request.getParameter("ISBN");
        
        RequestDispatcher r = request.getRequestDispatcher("ViewBook.jsp");
		r.include(request,response);
		out.println("<div class='container my-4'>");
		out.println("<h3 class='text-center'>Update Book Details</h3>");
		out.println("<div class='row justify-content-center'>");
		out.println("<div class='col-lg-6 col-md-8 col-sm-10'>");
		out.println("<form action='BookUpdate' method='Post'>");

		// ID field
		out.println("<div class='mb-3'>");
		out.println("<label for='bookId' class='form-label'>Book ID</label>");
		out.println("<input type='text' id='bookId' name='Id' value='" + Id + "' class='form-control' readonly/>");
		out.println("</div>");

		// Title field
		out.println("<div class='mb-3'>");
		out.println("<label for='title' class='form-label'>Title</label>");
		out.println("<input type='text' id='title' name='Title' value='" + Title + "' class='form-control' required/>");
		out.println("</div>");

		// Author field
		out.println("<div class='mb-3'>");
		out.println("<label for='author' class='form-label'>Author</label>");
		out.println("<input type='text' id='author' name='Author' value='" + Author + "' class='form-control' required/>");
		out.println("</div>");

		// Publisher field
		out.println("<div class='mb-3'>");
		out.println("<label for='publisher' class='form-label'>Publisher</label>");
		out.println("<input type='text' id='publisher' name='Publisher' value='" + Publisher + "' class='form-control' required/>");
		out.println("</div>");

		// Publish Date field
		out.println("<div class='mb-3'>");
		out.println("<label for='publishDate' class='form-label'>Publish Date</label>");
		out.println("<input type='date' id='publishDate' name='Publication_Date' value='" + Publication_Date + "' class='form-control' required/>");
		out.println("</div>");

		// ISBN field
		
        out.println("<div class='mb-3'>");
        out.println("<label for='isbn' class='form-label'>ISBN</label>");
        out.println("<input type='text' id='isbn' name='ISBN' value='" + ISBN + "' class='form-control' required/>");
        out.println("</div>");

		// Submit button
		out.println("<div class='text-center'>");
		out.println("<input type='submit' name='s' value='Update Book Details' class='btn btn-primary'/>");
		out.println("</div>");

		out.println("</form>");
		out.println("</div>");
		out.println("</div>");
		out.println("</div>");

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
