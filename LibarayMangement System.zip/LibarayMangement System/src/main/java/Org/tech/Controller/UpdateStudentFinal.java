package Org.tech.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UpdateStudentFinal")
public class UpdateStudentFinal extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int id = Integer.parseInt(request.getParameter("Id"));
		String Fullname=request.getParameter("Fullname");
		String Usernmae=request.getParameter("Username");
		String Password=request.getParameter("Password");
		String Email=request.getParameter("Email");
		String Phonenumber=request.getParameter("Phonenumber");
		String Address=request.getParameter("Address");
		   RequestDispatcher r = request.getRequestDispatcher("ViewStudent.jsp");
			r.include(request,response);
			
			out.println("<div class='container my-4'>");
			out.println("<h3 class='text-center'>Update User Profile</h3>");
			out.println("<div class='row justify-content-center'>");
			out.println("<div class='col-lg-6 col-md-8 col-sm-10'>");
			out.println("<form action='UpdateStudent' method='Post'>");

			// ID field (readonly)
			out.println("<div class='mb-3'>");
			out.println("<label for='userId' class='form-label'>User ID</label>");
			out.println("<input type='text' id='userId' name='Id' value='" + id + "' class='form-control' readonly/>");
			out.println("</div>");

			// Full Name field
			out.println("<div class='mb-3'>");
			out.println("<label for='fullName' class='form-label'>Full Name</label>");
			out.println("<input type='text' id='fullName' name='Fullname' value='" + Fullname + "' class='form-control' required/>");
			out.println("</div>");

			// Username field
			out.println("<div class='mb-3'>");
			out.println("<label for='username' class='form-label'>Username</label>");
			out.println("<input type='text' id='username' name='Username' value='" + Usernmae + "' class='form-control' required/>");
			out.println("</div>");

			// Password field
			out.println("<div class='mb-3'>");
			out.println("<label for='password' class='form-label'>Password</label>");
			out.println("<input type='password' id='password' name='Password'  value='" + Usernmae + "'placeholder='Enter new password' class='form-control' required/>");
			out.println("</div>");

			// Email field
			out.println("<div class='mb-3'>");
			out.println("<label for='email' class='form-label'>Email</label>");
			out.println("<input type='email' id='email' name='Email' value='" + Email + "' class='form-control' required/>");
			out.println("</div>");

			// Phone Number field
			out.println("<div class='mb-3'>");
			out.println("<label for='phone' class='form-label'>Phone Number</label>");
			out.println("<input type='tel' id='phone' name='Phonenumber' value='" + Phonenumber + "' class='form-control' required/>");
			out.println("</div>");

			// Address field
			out.println("<div class='mb-3'>");
			out.println("<label for='address' class='form-label'>Address</label>");
			out.println("<input type='text' id='address' name='Address' value='" + Address + "' class='form-control' required/>");
			out.println("</div>");

			// Submit button
			out.println("<div class='text-center'>");
			out.println("<input type='submit' value='Update Profile' class='btn btn-primary'/>");
			out.println("</div>");

			out.println("</form>");
			out.println("</div>");
			out.println("</div>");
			out.println("</div>");

			
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
