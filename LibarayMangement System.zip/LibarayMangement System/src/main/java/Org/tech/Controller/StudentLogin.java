package Org.tech.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Org.tech.servies.StudentUserServiceesIMPL;
import jakarta.servlet.http.HttpSession;


@WebServlet("/StudentLogin")
public class StudentLogin extends HttpServlet {
	StudentUserServiceesIMPL student=new StudentUserServiceesIMPL();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String useremail = request.getParameter("Email");
		System.out.println("Customer user is" + useremail);
		String Password = request.getParameter("Password");
		System.out.println("Customer password" +Password);	
		int result=student.isStudentLoginpresent(useremail, Password);
		if(result!=0)
		{   
			javax.servlet.http.HttpSession session=  request.getSession(true);
			session.setAttribute("CID",result);
			RequestDispatcher r=request.getRequestDispatcher("AdminHomePage.jsp");
     		r.forward(request, response);
			
		}
		else
		{
			out.println("Login  not Sccessfully");
		}
	}

	
	
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
