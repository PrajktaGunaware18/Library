package Org.tech.Controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;

import Org.tech.servies.StudentUserServiceesIMPL;



@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {
	StudentUserServiceesIMPL student=new StudentUserServiceesIMPL();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String useremail = request.getParameter("Email");
		System.out.println("Customer user is" + useremail);
		String Password = request.getParameter("Password");
		System.out.println("Customer password" +Password);	
		int result=student.isStudentLoginpresent(useremail, Password);
		if(result!=0)
		{   
			jakarta.servlet.http.HttpSession session=request.getSession(true);
			session.setAttribute("CID",result);
			jakarta.servlet.RequestDispatcher r=request.getRequestDispatcher("AdminHomePage.jsp");
     		r.forward(request, response);
			
		}
		else
		{
			out.println("Login  not Sccessfully");
		}
	}

	
	

}
