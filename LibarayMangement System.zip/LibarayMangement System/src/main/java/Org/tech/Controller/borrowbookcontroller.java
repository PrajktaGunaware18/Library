package Org.tech.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Org.tech.Model.borrowbook;
import Org.tech.servies.borrowbookservicesIMPL;


@WebServlet("/borrowbookcontroller")
public class borrowbookcontroller extends HttpServlet {
	borrowbookservicesIMPL borrow =new borrowbookservicesIMPL();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int bookid=Integer.parseInt(request.getParameter("bookid"));
		int StudentId=Integer.parseInt(request.getParameter("StudentId"));
		String borrow_date=request.getParameter("borrow_date");
		String Return_Date=request.getParameter("Return_Date");
		String Status=request.getParameter("Status");
		borrowbook bk=new borrowbook();
		bk.setBookid(bookid);
		bk.setStudentId(StudentId);
		bk.setBorrow_date(borrow_date);
		bk.setReturn_Date(Return_Date);
		bk.setStatus(Status);
		boolean b=borrow.isAddBorrowbook(bk);
		if(b) {
			RequestDispatcher r1=request.getRequestDispatcher("Addborrow.jsp");
	 		   r1.forward(request,response);
	 		  System.out.println("<h1>----- Add Borrow----</h1>");
		}
		else
		{
			RequestDispatcher r1=request.getRequestDispatcher("Addborrow.jsp");
	 		   r1.forward(request,response);
	 		   System.out.println("<h1>-----Not Add Borrow----</h1>");
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
