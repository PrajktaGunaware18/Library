package Org.tech.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Org.tech.servies.borrowbookservicesIMPL;


@WebServlet("/DeleteBorrowBookServlet")
public class DeleteBorrowBookServlet extends HttpServlet {
	borrowbookservicesIMPL borrowbook=new borrowbookservicesIMPL();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int id = Integer.parseInt(request.getParameter("Id"));
		boolean b=borrowbook.isDeleteBrrowBook(id);
		if(b)
		{
			RequestDispatcher r=request.getRequestDispatcher("BorrowBookView.jsp");
			r.forward(request, response);
		}
		else
		{
			RequestDispatcher r=request.getRequestDispatcher("BorrowBookView.jsp");
			r.forward(request, response);
			out.println("<h1>Some problem is there</h1>");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
