package Org.tech.Repostiory;

import java.util.List;

import Org.tech.Model.book;
import Org.tech.Model.borrowbook;

public interface borrowbookinter {
	public boolean isAddBorrowbook(borrowbook brobook);
	public List<borrowbook> getAllBorrowbook();
	 public boolean isDeleteBrrowBook(int borrowId);
	 public boolean isUpdateBorrowBook(int borrowid,int bookid,int studentid,String borrow_date ,String Return_Date,String Status);


}
