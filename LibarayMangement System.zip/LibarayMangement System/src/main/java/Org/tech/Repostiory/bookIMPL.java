package Org.tech.Repostiory;

import java.util.ArrayList;
import java.util.List;

import Org.tech.Config.DBConfig;
import Org.tech.Model.book;

public class bookIMPL extends DBConfig implements BookInterface{
	List<book> list = new ArrayList<book>();
	@Override
	public boolean isAddBook(book book) {
	try {
		stmt=con.prepareStatement("insert into book values('0',?,?,?,?,?)");
		stmt.setString(1,book.getTitle());
		stmt.setString(2,book.getAuthor());
		stmt.setString(3,book.getPublisher());
		stmt.setString(4,book.getPublication_Date());
		stmt.setString(5,book.getISBN());
		int value=stmt.executeUpdate();
		return value > 0 ?true:false;
	} catch (Exception e) {
		System.out.println("Error"+e);
		return false;
	}
		
	}

	@Override
	public List<book> getAllBook() {
		try {
			list = new ArrayList<book>();
			stmt=con.prepareStatement("select * from book");
			rs = stmt.executeQuery();

			while (rs.next()) {
				book model = new book();
				model.setBookid(rs.getInt(1));
				model.setTitle(rs.getString(2));
				model.setAuthor(rs.getString(3));
				model.setPublisher(rs.getString(4));
				model.setPublication_Date(rs.getString(5));
				model.setISBN(rs.getString(6));
				list.add(model);
			}
			return list.size() > 0 ? list : null;
		} catch (Exception e) {
			System.out.println("Error" + e);
			return null;
		}
		
	}

	@Override
	public boolean isDeletebook(int bookid) {
		try {
			stmt=con.prepareStatement("delete from book where bookid=?");
			stmt.setInt(1, bookid);
			int value = stmt.executeUpdate();
			return value > 0 ? true : false;
			
			
		} catch (Exception e) {
			System.out.println("Error"+e);
			return false;
		}
		
	}

	@Override
	public boolean isUpdatebook(int id, String Title, String Author, String Publisher, String Publication_Date,String ISBN) {
		try {
			stmt=con.prepareStatement("update book set Title=?,Author=?,Publisher=?,Publication_Date=?,ISBN=? where bookid =?");
			stmt.setString(1,Title);
			stmt.setString(2,Author);
			stmt.setString(3,Publisher);
			stmt.setString(4,Publication_Date);
			stmt.setString(5,ISBN);
			stmt.setInt(6,id);
			int value = stmt.executeUpdate();
		    return value > 0 ;
			
		} catch (Exception e) {
			System.out.println("Error"+e);
			return false;
		}
		
	}

	
}
