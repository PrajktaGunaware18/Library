package Org.tech.Repostiory;

import java.util.ArrayList;
import java.util.List;

import Org.tech.Config.DBConfig;
import Org.tech.Model.book;
import Org.tech.Model.borrowbook;

public class borrowbookIMPL extends DBConfig implements borrowbookinter {
	List<borrowbook> list = new ArrayList<borrowbook>();
	@Override
	public boolean isAddBorrowbook(borrowbook brobook) {
		try {
			stmt=con.prepareStatement("insert into borrowbook values('0',?,?,?,?,?)");
			stmt.setInt(1,brobook.getBookid());
			stmt.setInt(2,brobook.getStudentId());
			stmt.setString(3,brobook.getBorrow_date());
			stmt.setString(4,brobook.getReturn_Date());
			stmt.setString(5,brobook.getStatus());
			int value=stmt.executeUpdate();
			return value>0?true:false;
			
		} catch (Exception e) {
			System.out.println("Error"+e);
			return false;
		}
		
	}
	@Override
	public List<borrowbook> getAllBorrowbook() {
		try {
			list = new ArrayList<borrowbook>();
			stmt=con.prepareStatement("select * from borrowbook ");
			rs = stmt.executeQuery();

			while (rs.next()) {
				borrowbook b=new borrowbook();
				b.setBorrowId(rs.getInt(1));
				b.setBookid(rs.getInt(2));
				b.setStudentId(rs.getInt(3));
				b.setBorrow_date(rs.getString(4));
				b.setReturn_Date(rs.getString(5));
				b.setStatus(rs.getString(6));
				list.add(b);
				
			}
			return list.size() > 0 ? list : null;
			
			
		} catch (Exception e) {
			System.out.println("Error"+e);
			return null;
		}
		
	}
	@Override
	public boolean isDeleteBrrowBook(int borrowId) {
		try {
			
			stmt=con.prepareStatement("delete from borrowbook where borrowId=?");
			stmt.setInt(1, borrowId);
			int value = stmt.executeUpdate();
			return value > 0 ? true : false;
			
		} catch (Exception e) {
			System.out.println("Error"+e);
			return false;
			
		}
		
	
	}
	@Override
	public boolean isUpdateBorrowBook(int borrowid, int bookid, int studentid, String borrow_date, String Return_Date,
			String Status) {
		try {
			stmt=con.prepareStatement("update borrowbook set bookid=?,StudentId=?,borrow_date=?,Return_Date=?,Status=? where borrowId=? ");
			
			stmt.setInt(1,bookid);
			stmt.setInt(2,studentid);
			stmt.setString(3,borrow_date);
			stmt.setString(4,Return_Date);
			stmt.setString(5,Status);
			stmt.setInt(6, borrowid);
			
		
			int value = stmt.executeUpdate();
		    return value > 0 ;
			
		} catch (Exception e) {
			System.out.println("Error"+e);
			return false;
		}
		
	}

}
