package Org.tech.Repostiory;

import java.util.ArrayList;
import java.util.List;

import Org.tech.Config.DBConfig;
import Org.tech.Model.StudentUser;
import Org.tech.Model.book;

public class StudentRepstioryIMPL extends DBConfig implements StudentRepostiory{
	List<StudentUser> list = new ArrayList<StudentUser>();
	@Override
	public boolean isAddStudent(StudentUser student) {
		try {
			stmt= con.prepareStatement("insert into student values('0',?,?,?,?,?,?)");
			stmt.setString(1,student.getFullName());
			stmt.setString(2,student.getUsername());
			stmt.setString(3,student.getPassword());
			stmt.setString(4,student.getEmail());
			stmt.setString(5,student.getPhonenumber());
			stmt.setString(6,student.getAddress());
			int value=stmt.executeUpdate();
			return value > 0 ? true : false;
			
		} 
		catch (Exception e) 
		{
			System.out.println("Error"+e);
			return false;
		}
	
		
		
	}

	@Override
	public int isStudentLoginpresent(String Email, String Password) {
		try {
			stmt=con.prepareStatement("select * from student where  Email=? and Password=?");
			stmt.setString(1,Email);
			stmt.setString(2,Password);
			rs = stmt.executeQuery();
			System.out.println("Hello");
			
			if (rs.next()) {
				System.out.println("Hello");
				return rs.getInt(1);
			} else {
				System.out.println("Hello....");
				return 0;
			}

		} catch (Exception e) {
			return 0;
		}
		
	}

	@Override
	public List<StudentUser> getAllStudent() {
		try {
			list = new ArrayList<StudentUser>();
			stmt=con.prepareStatement("select *from Student");
			rs=stmt.executeQuery();
			while (rs.next()) {
				StudentUser student=new StudentUser();
				student.setStudentId(rs.getInt(1));
				student.setFullName(rs.getString(2));
				student.setUsername(rs.getString(3));
				student.setPassword(rs.getString(4));
				student.setEmail(rs.getString(5));
				student.setPhonenumber(rs.getString(6));
				student.setAddress(rs.getString(7));
				list.add(student);
				
				
			}
			return list.size() > 0 ? list : null;
			
			
		} catch (Exception e) {
			System.out.println("Error"+e);
			return null;
		}
		

	}

	@Override
	public boolean isDeletestudent(int StudentId) {
		try {
			stmt=con.prepareStatement("delete from Student where StudentId=?");
			stmt.setInt(1, StudentId);
			int value = stmt.executeUpdate();
			return value > 0 ? true : false;			
		} catch (Exception e) {
			System.out.println("Error"+e);
			return false;
		}
		
	}

	@Override
	public boolean isUpdateStudent(int StudentId, String fullname, String Username, String Password, String Email,
			String Phonenumber, String Address) {
		try {
			stmt=con.prepareStatement("update Student set FullName=?,username=?,Password=?, Email=?,Phonenumber=?,Address=? where StudentId=? ");
			stmt.setString(1,fullname);
			stmt.setString(2,Username);
			stmt.setString(3,Password);
			stmt.setString(4,Email);
			stmt.setString(5,Phonenumber);
			stmt.setString(6, Address);
			stmt.setInt(7, StudentId);
			int value = stmt.executeUpdate();
		    return value > 0 ;
			
		} catch (Exception e) {
			System.out.println("Error"+e);
			return false;
		}
		
	}

	@Override
	public StudentUser getAllStudent(int customeid) {
		try {
			stmt=con.prepareStatement("select *from student where StudentId=?");
			rs=stmt.executeQuery();
			StudentUser c=null;
			if(rs.next())
			{
				c=new StudentUser();
			
				c.setFullName(rs.getString(1));
				c.setUsername(rs.getString(2));
				c.setPassword(rs.getString(3));
				c.setEmail(rs.getString(4));
				c.setPhonenumber(rs.getString(5));
				c.setAddress(rs.getString(6));
			}
			return c;
			
		} catch (Exception e) {
			return null;
		}
		
	}

}
