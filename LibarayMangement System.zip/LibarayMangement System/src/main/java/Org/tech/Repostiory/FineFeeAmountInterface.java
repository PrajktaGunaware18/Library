package Org.tech.Repostiory;

import java.util.List;

import Org.tech.Model.FineFee;
import Org.tech.Model.book;

public interface FineFeeAmountInterface {
	public boolean isAddFine(FineFee fine);
	public List<FineFee> getAllFine();

}
