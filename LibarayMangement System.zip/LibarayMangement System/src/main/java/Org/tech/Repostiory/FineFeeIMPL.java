package Org.tech.Repostiory;

import java.util.ArrayList;
import java.util.List;

import Org.tech.Config.DBConfig;
import Org.tech.Model.FineFee;
import Org.tech.Model.book;

public class FineFeeIMPL extends DBConfig implements FineFeeAmountInterface{
	List<FineFee> list = new ArrayList<FineFee>();
	@Override
	public boolean isAddFine(FineFee fine) {
		try {
			stmt=con.prepareStatement("insert into finefee values('0',?,?,?)");
			stmt.setString(1,fine.getBorrow_date());
			stmt.setInt(2,fine.getFine_Amount());
			stmt.setString(3,fine.getPayment_Status());
			int value=stmt.executeUpdate();
			return value > 0 ?true:false;
		} catch (Exception e) {
			System.out.println("Error"+e);
			return false;
		}
		
	}

	@Override
	public List<FineFee> getAllFine() {
		try {
			list=new ArrayList<FineFee>();
			stmt=con.prepareStatement("select * from finefee");
			rs = stmt.executeQuery();

			while (rs.next()) {
				FineFee f=new FineFee();
				f.setFineId(rs.getInt(1));
				f.setBorrow_date(rs.getString(2));
				f.setFine_Amount(rs.getInt(3));
				f.setPayment_Status(rs.getString(4));
				list.add(f);
			}
			return list.size() > 0 ? list : null;
			
		} catch (Exception e) {
			System.out.println("Error"+e);
			return null;
		}
		
	}

}
