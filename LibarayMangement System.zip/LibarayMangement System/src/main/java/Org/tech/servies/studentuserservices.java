package Org.tech.servies;

import java.util.List;

import Org.tech.Model.StudentUser;

public interface studentuserservices {
	public boolean isAddStudent(StudentUser student);
	public int isStudentLoginpresent(String Email, String Password);
	public List<StudentUser> getAllStudent();
	public boolean isDeletestudent(int StudentId);
	public boolean isUpdateStudent(int StudentId, String fullname, String Username, String Password, String Email,String Phonenumber, String Address);
	public StudentUser getAllStudent(int customeid);
}
