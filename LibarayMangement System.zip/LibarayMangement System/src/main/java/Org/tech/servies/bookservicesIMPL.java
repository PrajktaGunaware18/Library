package Org.tech.servies;

import java.util.List;

import Org.tech.Model.book;
import Org.tech.Repostiory.bookIMPL;

public class bookservicesIMPL implements bookservices {
	bookIMPL b=new bookIMPL();
	@Override
	public boolean isAddBook(book book) {
		
		return b.isAddBook(book);
	}
	@Override
	public List<book> getAllBook() {
		
		return b.getAllBook();
	}
	@Override
	public boolean isDeletebook(int bookid) {
		
		return b.isDeletebook(bookid);
	}
	@Override
	public boolean isUpdatebook(int id, String Title, String Author, String Publisher, String Publication_Date,
			String ISBN) {
		
		return b.isUpdatebook(id, Title, Author, Publisher, Publication_Date, ISBN);
	}

}
