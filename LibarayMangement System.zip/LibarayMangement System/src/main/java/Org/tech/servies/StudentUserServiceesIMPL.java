package Org.tech.servies;

import java.util.List;

import Org.tech.Model.StudentUser;
import Org.tech.Repostiory.StudentRepstioryIMPL;

public class StudentUserServiceesIMPL implements studentuserservices{
	StudentRepstioryIMPL studRepo=new StudentRepstioryIMPL();
	@Override
	public boolean isAddStudent(StudentUser student) {
		
		return studRepo.isAddStudent(student);
	}
	@Override
	public int isStudentLoginpresent(String Email, String Password) {
		
		return studRepo.isStudentLoginpresent(Email, Password);
	}
	@Override
	public List<StudentUser> getAllStudent() {
		
		return studRepo.getAllStudent();
	}
	@Override
	public boolean isDeletestudent(int StudentId) {
		
		return studRepo.isDeletestudent(StudentId) ;
	}
	@Override
	public boolean isUpdateStudent(int StudentId, String fullname, String Username, String Password, String Email,
			String Phonenumber, String Address) {
		
		return studRepo.isUpdateStudent(StudentId, fullname, Username, Password, Email, Phonenumber, Address);
	}
	@Override
	public StudentUser getAllStudent(int customeid) {
		
		return studRepo.getAllStudent(customeid);
	}

}