package Org.tech.servies;

import java.util.List;

import Org.tech.Model.borrowbook;

public interface borrowbookservice {
	public boolean isAddBorrowbook(borrowbook brobook);
	public List<borrowbook> getAllBorrowbook();
	public boolean isDeleteBrrowBook(int borrowId);
	 public boolean isUpdateBorrowBook(int borrowid,int bookid,int studentid,String borrow_date ,String Return_Date,String Status);


}
