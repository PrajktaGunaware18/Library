package Org.tech.servies;

import java.util.List;

import Org.tech.Model.FineFee;

public class FineFeeIMPL implements FineFeeService{
	FineFeeIMPL fine1=new FineFeeIMPL();
	@Override
	public boolean isAddFine(FineFee fine) {
		
		return fine1.isAddFine(fine);
	}
	@Override
	public List<FineFee> getAllFine() {
		
		return fine1.getAllFine();
	}

}
