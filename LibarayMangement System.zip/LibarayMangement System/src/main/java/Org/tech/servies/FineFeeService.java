package Org.tech.servies;

import java.util.List;

import Org.tech.Model.FineFee;

public interface FineFeeService {
	public boolean isAddFine(FineFee fine);
	public List<FineFee> getAllFine();
	
}
