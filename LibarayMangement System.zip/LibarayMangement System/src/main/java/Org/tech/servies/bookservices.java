package Org.tech.servies;

import java.util.List;

import Org.tech.Model.book;

public interface bookservices {
	public boolean isAddBook(book book);
	public List<book> getAllBook();
	public boolean isDeletebook(int bookid);
	public boolean  isUpdatebook(int id,String Title,String Author,String Publisher,String Publication_Date,String ISBN);
}
