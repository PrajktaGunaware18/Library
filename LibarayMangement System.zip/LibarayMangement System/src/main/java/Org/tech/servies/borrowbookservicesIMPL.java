package Org.tech.servies;

import java.util.List;

import Org.tech.Model.borrowbook;
import Org.tech.Repostiory.borrowbookIMPL;

public class borrowbookservicesIMPL implements borrowbookservice{
	borrowbookIMPL b=new borrowbookIMPL();
	@Override
	public boolean isAddBorrowbook(borrowbook brobook) {
		
		return b.isAddBorrowbook(brobook);
	}
	@Override
	public List<borrowbook> getAllBorrowbook() {
		return b.getAllBorrowbook();
	}
	@Override
	public boolean isDeleteBrrowBook(int borrowId) {
		
		return b.isDeleteBrrowBook(borrowId);
	}
	@Override
	public boolean isUpdateBorrowBook(int borrowid, int bookid, int studentid, String borrow_date, String Return_Date,
			String Status) {
		
		return b.isUpdateBorrowBook(borrowid, bookid, studentid, borrow_date, Return_Date, Status);
	}

}
